"""
Trading Bot Autónomo - Mean Reversion Strategy
Calcula indicadores internamente, opera en Bybit automáticamente.
Diseñado para correr en Docker/Coolify.
"""

import os
import json
import time
import logging
import threading
import ccxt
import pandas as pd
import pandas_ta as ta
from datetime import datetime, timezone
from flask import Flask, jsonify
from dotenv import load_dotenv

load_dotenv()

# ============================================================
# CONFIGURACIÓN
# ============================================================

API_KEY = os.getenv("BYBIT_API_KEY", "")
API_SECRET = os.getenv("BYBIT_API_SECRET", "")
TESTNET = os.getenv("BYBIT_TESTNET", "true").lower() == "true"

SYMBOLS = ["BTC/USDT:USDT", "ETH/USDT:USDT"]
# Nota: XAU/USDT no disponible como perpetuo en Bybit.
# Alternativa: PAXG/USDT (oro tokenizado) si querés un tercero descorrelacionado.
# Para agregarlo: añadir "PAXG/USDT:USDT" a la lista.

LEVERAGE = 3
RISK_PERCENT = 3.0
SL_ATR_MULT = 1.5
TP_ATR_MULT = 3.75          # Ratio 1:2.5
RSI_PERIOD = 14
RSI_OVERSOLD = 30
RSI_OVERBOUGHT = 70
EMA_FAST = 21
EMA_SLOW = 50
ATR_PERIOD = 14
MAX_DRAWDOWN_PCT = 15.0
CHECK_INTERVAL_SEC = 60     # Chequear cada 60 segundos

# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("/app/data/trades.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ============================================================
# ESTADO PERSISTENTE
# ============================================================

STATE_FILE = "/app/data/state.json"

def load_state():
    default = {"equity_peak": 0, "trades": [], "paused_until": None}
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, "r") as f:
                return json.load(f)
    except Exception as e:
        logger.warning(f"Error cargando estado: {e}")
    return default

def save_state(state):
    try:
        os.makedirs(os.path.dirname(STATE_FILE), exist_ok=True)
        with open(STATE_FILE, "w") as f:
            json.dump(state, f, indent=2, default=str)
    except Exception as e:
        logger.error(f"Error guardando estado: {e}")

state = load_state()

# ============================================================
# EXCHANGE
# ============================================================

def create_exchange():
    exchange = ccxt.bybit({
        "apiKey": API_KEY,
        "secret": API_SECRET,
        "options": {"defaultType": "linear"},
    })
    if TESTNET:
        exchange.set_sandbox_mode(True)
    return exchange

exchange = create_exchange()

# ============================================================
# DATOS DE MERCADO
# ============================================================

def fetch_ohlcv(symbol, timeframe, limit):
    """Obtener velas OHLCV."""
    try:
        bars = exchange.fetch_ohlcv(symbol, timeframe, limit=limit)
        df = pd.DataFrame(bars, columns=["timestamp", "open", "high", "low", "close", "volume"])
        df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
        return df
    except Exception as e:
        logger.error(f"Error obteniendo datos {symbol} {timeframe}: {e}")
        return None

def calculate_indicators(symbol):
    """
    Calcular los 3 indicadores:
    - RSI 14 en velas diarias (extremos)
    - EMA 21/50 en velas 1H (cambio estructura)
    - ATR 14 en velas 1H (sizing)
    """
    # Velas diarias para RSI
    df_daily = fetch_ohlcv(symbol, "1d", 60)
    if df_daily is None or len(df_daily) < RSI_PERIOD + 1:
        return None

    # Velas horarias para EMAs y ATR
    df_hourly = fetch_ohlcv(symbol, "1h", 100)
    if df_hourly is None or len(df_hourly) < EMA_SLOW + 1:
        return None

    # RSI diario
    df_daily["rsi"] = ta.rsi(df_daily["close"], length=RSI_PERIOD)

    # EMAs horarias
    df_hourly["ema_fast"] = ta.ema(df_hourly["close"], length=EMA_FAST)
    df_hourly["ema_slow"] = ta.ema(df_hourly["close"], length=EMA_SLOW)

    # ATR horario
    df_hourly["atr"] = ta.atr(
        df_hourly["high"], df_hourly["low"], df_hourly["close"], length=ATR_PERIOD
    )

    # Cruce de EMAs (última y penúltima vela horaria)
    curr = df_hourly.iloc[-1]
    prev = df_hourly.iloc[-2]

    ema_bullish_cross = (prev["ema_fast"] <= prev["ema_slow"]) and (curr["ema_fast"] > curr["ema_slow"])
    ema_bearish_cross = (prev["ema_fast"] >= prev["ema_slow"]) and (curr["ema_fast"] < curr["ema_slow"])

    return {
        "rsi_daily": df_daily["rsi"].iloc[-1],
        "ema_fast": curr["ema_fast"],
        "ema_slow": curr["ema_slow"],
        "ema_bullish_cross": ema_bullish_cross,
        "ema_bearish_cross": ema_bearish_cross,
        "atr": curr["atr"],
        "price": curr["close"],
        "timestamp": curr["timestamp"],
    }

# ============================================================
# TRADING
# ============================================================

def get_balance():
    try:
        bal = exchange.fetch_balance({"type": "swap"})
        return float(bal.get("USDT", {}).get("total", 0))
    except Exception as e:
        logger.error(f"Error obteniendo balance: {e}")
        return 0.0

def get_position(symbol):
    try:
        positions = exchange.fetch_positions([symbol])
        for pos in positions:
            size = float(pos.get("contracts", 0))
            if size > 0:
                return {
                    "side": pos["side"],
                    "size": size,
                    "notional": float(pos.get("notional", 0)),
                    "unrealized_pnl": float(pos.get("unrealizedPnl", 0)),
                    "entry_price": float(pos.get("entryPrice", 0)),
                }
        return None
    except Exception as e:
        logger.error(f"Error obteniendo posición {symbol}: {e}")
        return None

def set_leverage(symbol):
    try:
        exchange.set_leverage(LEVERAGE, symbol)
    except Exception:
        pass  # Ya configurado

def execute_trade(symbol, side, price, atr_value):
    """Ejecutar trade con SL y TP."""
    balance = get_balance()
    if balance <= 0:
        logger.warning("Balance insuficiente")
        return None

    sl_distance = SL_ATR_MULT * atr_value
    tp_distance = TP_ATR_MULT * atr_value

    # Position sizing
    risk_amount = balance * (RISK_PERCENT / 100)
    qty = risk_amount / sl_distance

    # Redondear al mínimo del mercado
    market = exchange.market(symbol)
    precision = market.get("precision", {}).get("amount", 8)
    min_qty = market.get("limits", {}).get("amount", {}).get("min", 0)

    qty = float(exchange.amount_to_precision(symbol, qty))
    if qty < min_qty:
        logger.warning(f"{symbol}: qty {qty} < min {min_qty}")
        return None

    # Calcular SL y TP
    if side == "buy":
        sl_price = price - sl_distance
        tp_price = price + tp_distance
    else:
        sl_price = price + sl_distance
        tp_price = price - tp_distance

    sl_price = float(exchange.price_to_precision(symbol, sl_price))
    tp_price = float(exchange.price_to_precision(symbol, tp_price))

    set_leverage(symbol)

    try:
        order = exchange.create_order(
            symbol=symbol,
            type="market",
            side=side,
            amount=qty,
            params={
                "stopLoss": {"triggerPrice": sl_price, "type": "market"},
                "takeProfit": {"triggerPrice": tp_price, "type": "market"},
            }
        )

        trade_record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "symbol": symbol,
            "side": side,
            "qty": qty,
            "price": price,
            "sl": sl_price,
            "tp": tp_price,
            "risk_usd": round(risk_amount, 2),
            "potential_usd": round(risk_amount * 2.5, 2),
            "balance": round(balance, 2),
            "order_id": order.get("id", "N/A"),
        }

        state["trades"].append(trade_record)
        save_state(state)

        logger.info(f"✅ {side.upper()} {symbol} | qty={qty} | SL={sl_price} | TP={tp_price} | risk=${risk_amount:.2f}")
        return trade_record

    except Exception as e:
        logger.error(f"❌ Error ejecutando {side} {symbol}: {e}")
        return None

# ============================================================
# CIRCUIT BREAKER
# ============================================================

def check_circuit_breaker():
    balance = get_balance()
    if balance <= 0:
        return True

    if state["equity_peak"] == 0:
        state["equity_peak"] = balance

    state["equity_peak"] = max(state["equity_peak"], balance)
    drawdown = (state["equity_peak"] - balance) / state["equity_peak"] * 100

    if drawdown >= MAX_DRAWDOWN_PCT:
        logger.warning(f"⛔ CIRCUIT BREAKER: drawdown {drawdown:.1f}% >= {MAX_DRAWDOWN_PCT}%")
        # Cerrar todas las posiciones
        for sym in SYMBOLS:
            pos = get_position(sym)
            if pos:
                close_side = "sell" if pos["side"] == "long" else "buy"
                try:
                    exchange.create_order(sym, "market", close_side, pos["size"], params={"reduceOnly": True})
                    logger.info(f"🔒 Cerrada posición {sym}")
                except Exception as e:
                    logger.error(f"Error cerrando {sym}: {e}")
        save_state(state)
        return True

    return False

# ============================================================
# LOOP PRINCIPAL
# ============================================================

def check_signals():
    """Evaluar señales para todos los símbolos."""
    logger.info("🔍 Evaluando señales...")

    if check_circuit_breaker():
        logger.warning("⛔ Circuit breaker activo — sin operaciones")
        return

    for symbol in SYMBOLS:
        try:
            # ¿Ya hay posición abierta?
            pos = get_position(symbol)
            if pos is not None:
                logger.info(f"📊 {symbol}: posición {pos['side']} abierta | PnL: ${pos['unrealized_pnl']:.2f}")
                continue

            # Calcular indicadores
            indicators = calculate_indicators(symbol)
            if indicators is None:
                logger.warning(f"⚠️ {symbol}: no se pudieron calcular indicadores")
                continue

            rsi = indicators["rsi_daily"]
            atr = indicators["atr"]
            price = indicators["price"]

            logger.info(
                f"📈 {symbol}: RSI_D={rsi:.1f} | "
                f"EMA21={'>' if indicators['ema_fast'] > indicators['ema_slow'] else '<'}EMA50 | "
                f"ATR={atr:.2f} | Price={price:.2f}"
            )

            # Señal LONG
            if rsi < RSI_OVERSOLD and indicators["ema_bullish_cross"]:
                logger.info(f"🟢 SEÑAL LONG {symbol}: RSI={rsi:.1f} + cruce alcista")
                execute_trade(symbol, "buy", price, atr)

            # Señal SHORT
            elif rsi > RSI_OVERBOUGHT and indicators["ema_bearish_cross"]:
                logger.info(f"🔴 SEÑAL SHORT {symbol}: RSI={rsi:.1f} + cruce bajista")
                execute_trade(symbol, "sell", price, atr)

            else:
                logger.info(f"⏸️ {symbol}: sin señal")

        except Exception as e:
            logger.error(f"Error procesando {symbol}: {e}")

    save_state(state)

# ============================================================
# HEALTH CHECK API
# ============================================================

app = Flask(__name__)

@app.route("/health", methods=["GET"])
def health():
    balance = get_balance()
    positions = {}
    for sym in SYMBOLS:
        pos = get_position(sym)
        if pos:
            positions[sym] = pos

    peak = state.get("equity_peak", balance)
    dd = ((peak - balance) / peak * 100) if peak > 0 else 0

    return jsonify({
        "status": "running",
        "testnet": TESTNET,
        "balance_usdt": round(balance, 2),
        "equity_peak": round(peak, 2),
        "drawdown_pct": round(dd, 1),
        "circuit_breaker": dd >= MAX_DRAWDOWN_PCT,
        "leverage": LEVERAGE,
        "risk_pct": RISK_PERCENT,
        "symbols": SYMBOLS,
        "open_positions": positions,
        "total_trades": len(state.get("trades", [])),
        "last_5_trades": state.get("trades", [])[-5:],
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })

@app.route("/trades", methods=["GET"])
def trades():
    return jsonify(state.get("trades", []))

@app.route("/", methods=["GET"])
def index():
    return jsonify({"service": "trading-bot", "status": "ok"})

# ============================================================
# MAIN
# ============================================================

def run_bot():
    """Loop del bot en thread separado."""
    logger.info("=" * 50)
    logger.info("🚀 Bot autónomo iniciando...")
    logger.info(f"   Testnet: {TESTNET}")
    logger.info(f"   Leverage: {LEVERAGE}x")
    logger.info(f"   Riesgo: {RISK_PERCENT}%")
    logger.info(f"   SL: {SL_ATR_MULT}x ATR | TP: {TP_ATR_MULT}x ATR")
    logger.info(f"   Símbolos: {SYMBOLS}")
    logger.info(f"   Intervalo: cada {CHECK_INTERVAL_SEC}s")
    logger.info(f"   Balance: ${get_balance():.2f} USDT")
    logger.info("=" * 50)

    # Primera ejecución inmediata
    check_signals()

    # Loop
    while True:
        time.sleep(CHECK_INTERVAL_SEC)
        try:
            check_signals()
        except Exception as e:
            logger.error(f"Error en loop principal: {e}")
            time.sleep(30)

if __name__ == "__main__":
    os.makedirs("/app/data", exist_ok=True)

    # Bot en thread separado
    bot_thread = threading.Thread(target=run_bot, daemon=True)
    bot_thread.start()

    # Health API en thread principal
    port = int(os.getenv("PORT", 3000))
    app.run(host="0.0.0.0", port=port, debug=False)
